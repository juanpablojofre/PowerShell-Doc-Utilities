function Test-HttpUrl2() {
    [CmdletBinding()]
    Param(
        [parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()]
        [string]$url,
        [parameter(Mandatory = $false)]
        [int]$MaximumRedirection = 5,
        [parameter(Mandatory = $false)]
        [int]$TimeoutSecs = 5,
        [parameter(Mandatory = $false)]
        [switch]$GetUserCredentials
        
    )

    BEGIN {
        [string]$initialWarningPreference = $WarningPreference
        [string]$initialErrorActionPreference = $ErrorActionPreference
        $secpasswd = ConvertTo-SecureString "PlainTextPassword" -AsPlainText -Force
        [System.Net.NetworkCredential]$Anonymous = [System.Net.NetworkCredential]::new("anonymous", $secpasswd)
        [System.Net.HttpWebResponse]$HttpResponse = [System.Net.HttpWebResponse]::new();
        [string]$result = "N/A"
    }

    END {
        Write-Progress $url
        ## Revert escaped characters in text
        [string]$weblink = Get-UnEscapedText $url

        try {
            $WarningPreference = 'SilentlyContinue'
            $ErrorActionPreference = 'SilentlyContinue'
            [System.Net.HttpWebRequest]$httpRequest = [System.Net.WebRequest]::Create($weblink)
            $httpRequest.Method = "HEAD"
            $httpRequest.AllowAutoRedirect = $true
            $httpRequest.MaximumAutomaticRedirections = $MaximumRedirection
            $httpRequest.Timeout = $TimeoutSecs * 1000
            $httpRequest.Credentials = $Anonymous
            if ($GetUserCredentials) {
                $httpRequest.Credentials = [System.Net.CredentialCache]::DefaultCredentials
            }

            $HttpResponse = [System.Net.HttpWebResponse]$httpRequest.GetResponse()
            $result = $HttpResponse.StatusCode.ToString()
        }
        catch [System.Net.WebException] {
            if ($_.Status -eq [System.Net.WebExceptionStatus]::ProtocolError) {
                $result = (([System.Net.HttpWebResponse]$_.Response).StatusCode).ToString()
            }
        }
        catch {
            ## Do nothing => SilentlyContinue
        }
        finally {
            $WarningPreference = $initialWarningPreference
            $ErrorActionPreference = $initialErrorActionPreference
            $result
        }
    }
}